<?php
// start a session to store information to be used across multiple pages
session_start();



// require a database connection
require('db_connect.php');

function logUserOut() {

}

function sanitizeData($input) {
    $data = trim($input);
    $data= stripslashes($data); 
    $data= htmlspecialchars($data);
    
    
    return $data;

}


// check which button has been clicked
// login button clicked
if (isset($_POST['submitbutton'])) {
    // get the submitted email and password and sanitize them
    $email = sanitizeData($_POST['inputEmail']);
    $pass = sanitizeData($_POST['inputPassword']);
   

    // hash user password before looking it up in the database
    $pass_hash = md5($pass);

    // create sql query to select user from database
    $sql = "SELECT * FROM customer WHERE customer_email='$email' && Password='$pass_hash'";

    //run the query and store result
    $result = mysqli_query($connection, $sql);
    
    // check if results were retrieved
    // login successful
    if (mysqli_num_rows($result) > 0) {
        // fetch result as an array
        $row = mysqli_fetch_assoc($result);
        
        // set retrieved user information in a session variable to be used across multiple pages
        $_SESSION[user_info] = $row ['customer_email'];

        // redirect user to their dashboard as they have successfully logged in
        header("Location: index.html");

    } else {
        // login failed
        // redirect user to login page again
        header("Location: loginpage.html");
    }

    // close database connection
    mysqli_close($connection);


    // signup button clicked
	} else if (isset($_POST['submitbutton'])) {
		// get the submitted username and password and sanitize them
		$email = sanitizeData($_POST['inputEmail']);
        $pass = sanitizeData($_POST['inputPassword']);
        $fname = sanitizeData($_POST['inputFName']);
        $lname = sanitizeData($_POST['inputLName']);
        $idnum = sanitizeData($_POST['inputID']);

		// encrypt password before storing to database
		$pass_hash = md5($pass);

		// create sql query to insert user into the database
		$sql = "INSERT INTO costumer (costumer_f_name, costumer_l_name,customer_id,costumer_email,customer_pword)
        VALUES('$fname','$lname','$idnum','$email','$pass_hash')";


		//run the query and store result
		$result = mysqli_query($connection, $sql);
		
		//check if results were retrieved
		if ($result > 0) {
	    	// redirect user to login page
	    	header("Location: loginpage.html");
		} else {
	    	// redirect user to sign up page
			header("Location: signup.html");
			// display error
			echo "registration failed";
		}

		// close database connection
		mysqli_close($connection);

	} elseif (isset($_GET['logout'])) {
		logUserOut();
	}
?>
