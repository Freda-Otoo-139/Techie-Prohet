<?php
	
	require('db_connect.php');
	//check if the button has been clicked
	if (isset($_POST['placeorder'])) {
		$customer_id = $_POST['customerId'];
		$location = $_POST['customerLocation']; //keep location
		$meal_name = $_POST['meal']; 
		if(isset($_POST['portiontype'])){
			$portion_type = $_POST['portiontype'];
		}
		if($portion_type=="Full portion"){
			$order_price = "GHS8.50";
		}
		else{
			$order_price = "GHS11.00";
		}
		$order_quantity = 1;
		//echo $mname."<br>";
		$sql = "SELECT * FROM meals WHERE meal_name ='$meal_name'";
		$result = mysqli_query($connection, $sql);

		//select from worker
		$sql_worker ="SELECT * FROM workers ORDER BY RAND() LIMIT 1";
		$worker_result = mysqli_query($connection, $sql_worker);

	}
	////////////////////////////////////////////////////////////////////////////
	if (mysqli_num_rows($worker_result) > 0) {
    	// output data of each row
    	//the mysqli_fetch_assoc function puts the results in an assoiciative array
    	while($row_1 = mysqli_fetch_assoc($worker_result)) {
        	$worker_id = $row_1["worker_id"];
    	}
	} else {
    	echo "there are no results";
	}
	////////////////////////////////////////////////////////////////////////////

	//the mysqli_num_rows function checks if the results are more than zero
	if (mysqli_num_rows($result) == 1) {
    	// output data of each row
    	//the mysqli_fetch_assoc function puts the results in an assoiciative array
    	while($row = mysqli_fetch_assoc($result)) {
        	$mealId = $row["meal_id"];
    	}
	} else {
    	echo "there are no results";
	}
	
	///////////////////////////////////////////////////////////////////////////////
	//for inserting into
	$customer_order_insert = "INSERT INTO orders (meal_id,order_price,order_portion,order_quantity)
		 VALUES('$mealId','$order_price','$portion_type','$order_quantity')";
	if(mysqli_query($connection,$customer_order_insert)){
		echo"successfully inserted";
	}else{
		echo"error: ".$sql."<br>".mysqli_error($connection);
	}
	////////////////////////////////////////////////////////////////////////////////
	//code to select order number comes here

	////////////////////////////////////////////////////////////////////////////////
	$deliveries_insert = "INSERT INTO deliveries (meal_id,location,worker_id)
		 VALUES('$mealId','$location','$worker_id')";
	if(mysqli_query($connection,$deliveries_insert)){
		echo"successfully inserted";
	}else{
		echo"error: ".$sql."<br>".mysqli_error($connection);
	}

	mysqli_close($connection);


?>