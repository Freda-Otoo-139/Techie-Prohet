<?php
session_start();



// require a database connection
require('db_connect.php');

function logUserOut() {

}

function sanitizeData($input) {
    $data = trim($input);
    $data= stripslashes($data); 
    $data= htmlspecialchars($data);   
    
    return $data;

}


// check which button has been clicked
// login button clicked
if (isset($_POST['submitLogin'])) {
    // get the submitted email and password and sanitize them
    $email = sanitizeData($_POST['inputEmail']);
    $pass = sanitizeData($_POST['inputPassword']);
    $salt = 'Username20Jun96';
	$hashed_pword = hash('gost', $pass.$salt);

    // create sql query to select user from database
    $sql = "SELECT * FROM customer WHERE customer_email='$email' && Password='$hashed_pword'";

    //run the query and store result
    $result = mysqli_query($connection, $sql);
    
    // check if results were retrieved
    // login successful
    if (mysqli_num_rows($result) > 0) {
        // fetch result as an array
        $row = mysqli_fetch_assoc($result);
        
        // set retrieved user information in a session variable to be used across multiple pages
        $_SESSION[user_info] = $row ['customer_email'];

        // redirect user to their dashboard as they have successfully logged in
        header("Location: contact.html");

    } else {
        // login failed
        // redirect user to login page again
        header("Location: loginpage.html");
    }

    // close database connection
    mysqli_close($connection);


    // signup button clicked
	} else if (isset($_POST['submitSignup'])) {
        $email = sanitizeData($_POST['inputEmail']);
		$pass = sanitizeData($_POST['inputPassword']);
		$fname = sanitizeData($_POST['inputFName']);
		$lname = sanitizeData($_POST['inputLName']);
		$idnum = sanitizeData($_POST['inputID']);
		$salt = 'Username20Jun96';
		$hashed_pword = hash('gost', $pass.$salt);

		// create sql query to insert user into the database
		$sql = "INSERT INTO customer (customer_id,customer_f_name, customer_l_name,customer_email,customer_pword)
        	VALUES('$idnum','$fname','$lname','$email','$hashed_pword')";


		//run the query and store result
		$result = mysqli_query($connection, $sql);
		
		//check if results were retrieved
		if ($result > 0) {
	    	// redirect user to login page
	    	header("Location: loginpage.html");
		} else {
	    	// redirect user to sign up page
			header("Location: signup.html");
			// display error
			echo "registration failed";
		}

		// close database connection
		mysqli_close($connection);

	} elseif (isset($_GET['logout'])) {
		logUserOut();
	}
?>