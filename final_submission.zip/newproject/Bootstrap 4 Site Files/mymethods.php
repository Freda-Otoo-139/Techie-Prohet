<?php
	//declare variables for my database connection 
	require('db_connect.php');

	//check if the button has been clicked
	if (isset($_POST['sendMessage'])) {
		$mname = $_POST['inputEmail'];
		$user_msg = $_POST['message'];
		$id_custmer_table = null;
		
		//echo $mname."<br>";
		$sql = "SELECT * FROM customer WHERE customer_email ='$mname'";
		$result = mysqli_query($connection, $sql);

		//////////////////////////////////////////////////////////////
		//for insert
		$sql_insert = "INSERT INTO feedback (message)
		 VALUES('$user_msg')";

	}

	//the mysqli_num_rows function checks if the results are more than zero
	if (mysqli_num_rows($result) > 0) {
    	// output data of each row
    	//the mysqli_fetch_assoc function puts the results in an assoiciative array
    	while($row = mysqli_fetch_assoc($result)) {
        	$id_custmer_table = $row["customer_id"];
        	echo $id_custmer_table;
    	}
	} else {
    	echo "there are no results";
	}
	
	/////////////////////////////////////////////////////////////////////////////
	//for the insert
	if(mysqli_query($connection,$sql_insert)){
		echo"successfully inserted";
	}else{
		echo"error: ".$sql_insert."<br>".mysqli_error($connection);
	}
	/////////////////////////////////////////////////////////////////////////////
	$sql_msgselect = "SELECT * FROM feedback WHERE message = '$user_msg'";
	$selecte_msg = mysqli_query($connection, $sql_msgselect);
	//the mysqli_num_rows function checks if the results are more than zero
	if (mysqli_num_rows($selecte_msg) > 0) {
    	// output data of each row
    	//the mysqli_fetch_assoc function puts the results in an assoiciative array
    	while($row_one = mysqli_fetch_assoc($selecte_msg)) {
        	$id_from_fback = $row_one["feedback_number"]; 
    	}
	} else {
    	echo "0 results";
	}
	///////////////////////////////////////////////////////////////////////////////
	//for inserting into
	$customer_fback_insert = "INSERT INTO customer_feedback (customer_id,feedback_number,some_message)
		 VALUES('$id_custmer_table','$id_from_fback','$user_msg')";
	if(mysqli_query($connection,$customer_fback_insert)){
		echo"successfully inserted";
	}else{
		echo"error: ".$sql."<br>".mysqli_error($connection);
	}

	mysqli_close($connection);


?>