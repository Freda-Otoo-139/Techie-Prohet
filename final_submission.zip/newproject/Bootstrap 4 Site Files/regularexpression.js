// regular expression for email
var regrex = new RegExp(^\w + ([\.-] ?\w +) *@\w + ([\.-] ?\w +)* (\.\w{ 2, 3 }) +$, img);


//create function to check email validity
function chkemail() {
    var email = document.getElementById("inputEmail").value;


    //compare email with regular expression
    var check = regrex.test(email);

    if (check) {
        alert("Your email is valid")
    }

    else {
        alert("Sorry, invalid email!")
    }



}


//regular expression for id number

var regid = new RegExp(^ [0 - 9] + $, img);

//create function to check id number validility
function checkid() {
    var idnumb = document.getElementById("inputID").value;


    //compare id number with regular expression 
    var verify = regid.test(idnumb);

    if (verify) {
        alert("Valid ID Number")
    }

    else {
        alert("Your ID Number is invalid.")
    }
}