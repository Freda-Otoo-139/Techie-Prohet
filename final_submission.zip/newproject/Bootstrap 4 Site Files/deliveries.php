<?php
	require('db_connect.php');

	//check if the button has been clicked
	if (isset($_POST['placeorder'])) {
		$customer_id = $_POST['customerId'];
		$location = $_POST['customerLocation']; //keep location
		$meal_name = $_POST['meal']; 
		
		//echo $mname."<br>";
		$sql = "SELECT * FROM meals WHERE meal_name ='$meal_name";
		$result = mysqli_query($connection, $sql);

		$sql0 = "SELECT * FROM orders WHERE meal_name ='$meal_name";
		$result = mysqli_query($connection, $sql0);
		//for insert into feedback table
		$sql_insert = "INSERT INTO feedback (message)
		 VALUES('$user_msg')";

	}

	//the mysqli_num_rows function checks if the results are more than zero
	if (mysqli_num_rows($result) > 0) {
    	// output data of each row
    	//the mysqli_fetch_assoc function puts the results in an assoiciative array
    	while($row = mysqli_fetch_assoc($result)) {
        	$id_custmer_table = $row["customer_id"];
    	}
	} else {
    	echo "there are no results";
	}
	if(mysqli_query($connection,$sql_insert)){
		echo "Thank you, ";
	}else{
		echo"error: ".$sql_insert."<br>".mysqli_error($connection);
	}
	//gets user feedback id from the feedback table
	$sql_msgselect = "SELECT * FROM feedback WHERE message = '$user_msg'";
	$selecte_msg = mysqli_query($connection, $sql_msgselect);
	//the mysqli_num_rows function checks if the results are more than zero
	if (mysqli_num_rows($selecte_msg) > 0) {
    	// output data of each row
    	//the mysqli_fetch_assoc function puts the results in an assoiciative array
    	while($row_one = mysqli_fetch_assoc($selecte_msg)) {
        	$id_from_fback = $row_one["feedback_number"]; 
    	}
	} else {
    	echo "0 results";
	}
	//for inserting into customer_feedback table
	$customer_fback_insert = "INSERT INTO customer_feedback (customer_id,feedback_number,some_message)
		 VALUES('$id_custmer_table','$id_from_fback','$user_msg')";
	if(mysqli_query($connection,$customer_fback_insert)){
		echo"For your feedback";
	}else{
		echo"error: ".$sql."<br>".mysqli_error($connection);
	}

	mysqli_close($connection);


?>