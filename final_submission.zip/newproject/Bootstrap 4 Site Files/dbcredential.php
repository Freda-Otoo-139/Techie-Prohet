<?php
//Database credentials
define("DATABASE", "tp2021");
define("SERVER", "localhost");
define("USERNAME", "root");
define("PASSWD", "");

?>