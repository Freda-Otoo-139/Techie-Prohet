<?php
//database

//database credentials
require('dbms_connect.php');

/**
 *@author Kofi F. Boamah
 *@version 1.1
 */
class dbms_connection
{
	//properties
	public $db = null; // null reduces the chances of error
	public $results = null;

	//connect
	/**
	*Database connection
	*@return bolean
	**/
	function db_connect(){
		//connection
		$this->db = mysqli_connect(SERVER,USERNAME,PASSWD,DATABASE); // reason for the 'this->' reference is for the concept of global and local variable. makes sure the update or input affects the variable.
		
		//test the connection
		if (mysqli_connect_errno()) {
			return false;
		}else{
			return true;
		}
	}

	//execute a query
	/**
	*Query the Database
	*@param takes a connection and sql query
	*@return bolean
	**/
	function db_query($sqlQuery){
		if (!$this->db_connect()) {
			return false;
		} 
		elseif ($this->db==null) {
			return false;
		}

		//run query 
		$this->results = mysqli_query($this->db,$sqlQuery);
		if ($this->results == false) {
			return false;
		}else{
			return true;
		}
		
	}
	
?>