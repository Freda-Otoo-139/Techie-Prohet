<?php
	session_start();

	function fetchatoken($form) {

    	// generate a token from an unique value, took from microtime, you can also use salt-values, other crypting methods...
    	$token = md5(uniqid(microtime(), true));  

    	// Write the generated token to the session variable to check it against the hidden field when the form is sent
    	$_SESSION['token'][$form] = $token; 
    	return $token;
	}

	// initializing variables
	private $password = "";
	protected $email    = "";
	$errors = array(); 

		// LOGIN USER
	if (isset($_POST['login_user'])) {
	  $email = mysqli_real_escape_string($db, $_POST['inputEmail']);
	  $password = mysqli_real_escape_string($db, $_POST['inputPassword']);

	  if (empty($email)) {
	  	array_push($errors, "Email is required");
	  }
	  if (empty($password)) {
	  	array_push($errors, "Password is required");
	  }

	  if (count($errors) == 0) {
	  	$password = md5($password);
	  	$query = "SELECT email, password FROM users WHERE email='$email' AND password='$password'";
	  	$results = mysqli_query($db, $query);
	  	if (mysqli_num_rows($results) == 1) {
	  	  $_SESSION['email'] = $email;
	  	  $_SESSION['success'] = "You are now logged in";
	  	  header('location: index.php');
	  	}else {
	  		array_push($errors, "Wrong email/password combination");
	  	}
	  }
	}
?>