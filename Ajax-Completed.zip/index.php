<!DOCTYPE html>
<html>
<head>
	<title>Ajax</title>
	<script type="text/javascript" src="jquery-3.4.1.js"></script>
	<script type="text/javascript" src="myajax.js"></script>
</head>
<body>
	<div style="margin: 0 auto; text-align: center; padding-top: 10%; font-size: 20px;">
		<h1>Learn Ajax</h1>

		<form>
			<label>Search Term</label>
			<input type="text" size="25" name="sterm" id="shterm">
			<!--
			<input onclick="gotoServer()" type="submit" name="findme" value="Search">
			-->
		</form>

		<span id="showhere"></span>
	</div>
</body>
</html>